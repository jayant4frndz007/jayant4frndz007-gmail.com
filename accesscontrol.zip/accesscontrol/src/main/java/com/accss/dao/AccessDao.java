package com.accss.dao;

public class AccessDao {

	public String getData() {
		// TODO Auto-generated method stub
		return "Hello Jayant";
	}

}

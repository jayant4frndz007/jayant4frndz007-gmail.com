package com.accss.accesscontrol;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class FirstController {

	// inject via application.properties
	

	@GetMapping(value="/")
	public String welcome() {
		return "Welcome";
	}
	@GetMapping(value="/login")
	public String login() {
		return "login";
	}
	
	

}

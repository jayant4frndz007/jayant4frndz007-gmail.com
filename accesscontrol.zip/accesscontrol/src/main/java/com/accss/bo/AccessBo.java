package com.accss.bo;

import com.accss.dao.AccessDao;

public class AccessBo {
	AccessDao dao=new AccessDao();
	public String getData() {
		// TODO Auto-generated method stub
		return dao.getData();
	}

}
